#include <iostream>

using namespace std;

int main() {
    // here is a template to help get you started
    // declare some variables
    int m, n;

    // read in the first line of input
    cin >> m >> n;

    // now solve the problem and output the result!

    return 0;
}
