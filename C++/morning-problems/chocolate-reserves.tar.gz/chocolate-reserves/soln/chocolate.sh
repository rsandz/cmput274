#!/bin/bash
g++ chocolate.cpp -o chocolate -Wall && ./chocolate
rm -f ./chocolate
