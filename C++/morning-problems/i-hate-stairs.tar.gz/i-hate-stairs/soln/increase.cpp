#include <iostream>

using namespace std;

int main() {
  int n;
  int array[1000];

  // read in the input

  // now compute and print the answer

  return 0;
}
