#include <iostream>

using namespace std;

int main() {
  // Put your code here!

  return 0;
}
