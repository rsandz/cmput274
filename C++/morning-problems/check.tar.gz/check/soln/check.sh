#!/bin/bash
g++ -Wall check.cpp -o check && ./check
rm ./check
