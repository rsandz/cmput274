import sys

for line in sys.stdin:
    # be mindful that line may have a trailing \n character
    pass
