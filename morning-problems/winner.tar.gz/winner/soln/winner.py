# Read the input
n = int(input())